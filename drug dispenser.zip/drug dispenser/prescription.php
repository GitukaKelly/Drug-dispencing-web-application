<?php
require('config.php');

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $name = $_POST["name"];
    $dose = $_POST["dose"];
    $frequency = $_POST["frequency"];
    $days = $_POST["days"];
    $quantity = $_POST["quantity"];
    $patient_name = $_POST["patient_name"];

    // Retrieve patient_id from the patient table based on the patient name
    $sql_patient_id = "SELECT patient_id FROM patient WHERE patient_name = '$patient_name'";
    $result_patient_id = $conn->query($sql_patient_id);
    $row_patient_id = $result_patient_id->fetch_assoc();
    $patient_id = $row_patient_id["patient_id"];

    // Insert prescription into the prescription table
    $sql_insert = "INSERT INTO prescriptions (name ,dose, Frequency, Days, quantity, patient_id)
                    VALUES ('$name', '$dose', '$frequency', '$days', '$quantity', '$patient_id')";

    if ($conn->query($sql_insert) === TRUE) {
        echo "Prescription saved successfully.";
    } else {
        echo "Error: " . $sql_insert . "<br>" . $conn->error;
    }
}

// Retrieve drug names from the drug table
$sql_drugs = "SELECT name FROM drug";
$result_drugs = $conn->query($sql_drugs);

// Retrieve patient names from the patient table
$sql_patients = "SELECT patient_name FROM patient";
$result_patients = $conn->query($sql_patients);
?>
<!DOCTYPE html>
<html>
<head>
    <title>Prescriptions</title>
</head>
<body>
    <link rel="stylesheet"href="style.css"/>
<html>
<head>
    <title>New Prescription</title>
    <style>
        body {
            background-color: #f2f2f2;
            font-family: Arial, sans-serif;
        }

        h2 {
            text-align: center;
            margin: 20px 0;


        }
        title{

        }

        form {
            width: 300px;
            margin: 0 auto;
            padding: 20px;
            border: 1px solid #ddd;
            background-color: yellow;
        }

        label {
            display: inline-block;
            width: 100px;
            margin-bottom: 10px;
        }

        input[type="text"] {
            width: 200px;
            padding: 5px;
            margin-bottom: 10px;
            border: 1px solid #ddd;
        }

        input[type="submit"] {
            background-color: black;
            color: white;
            padding: 10px 20px;
            border: none;
            cursor: pointer;
        }

        .error-message {
            color: red;
            font-size: 14px;
        }
    </style>
    <h2>New Prescription</h2>

    <form method="post">
        <label for="name">Drug Name:</label>
        <select name="name">
            <?php
            // Populate drug names dropdown
            if ($result_drugs->num_rows > 0) {
                while ($row = $result_drugs->fetch_assoc()) {
                    echo "<option value='" . $row["name"] . "'>" . $row["name"] . "</option>";
                }
            }
            ?>
        </select>
        <br><br>

        <label for="dose">Dose:</label>
        <input type="text" name="dose" required>
        <br><br>

        <label for="frequency">Frequency:</label>
        <input type="text" name="frequency" required>
        <br><br>

        <label for="days">Days:</label>
        <input type="text" name="days" required>
        <br><br>

        <label for="quantity">Quantity:</label>
        <input type="text" name="quantity" required>
        <br><br>

        <label for="patient_name">Patient Name:</label>
        <select name="patient_name">
            <?php
            // Populate patient names dropdown
            if ($result_patients->num_rows > 0) {
                while ($row = $result_patients->fetch_assoc()) {
                    echo "<option value='" . $row["patient_name"] . "'>" . $row["patient_name"] . "</option>";
                }
            }
            ?>
        </select>
        <br><br>

        <input type="submit" value="Submit">
    </form>
     <a href="search.php">Back to search</a>
</body>
</html>
