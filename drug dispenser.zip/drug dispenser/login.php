<?php

require 'config.php';
if (isset($_POST["submit"])) {
  $usernameid = $_POST["usernameid"];
  $password = $_POST["password"];

  $result = mysqli_query($conn, "SELECT * FROM tb_user WHERE occupation='Doctor' AND (username = '$usernameid' OR id = '$usernameid')");

  if (mysqli_num_rows($result) > 0) {
    $row = mysqli_fetch_assoc($result);
    if ($password == $row['password']) {
      $_SESSION["login"] = true;
      $_SESSION["id"] = $row["id"];
      header("Location: dashboard.php");
      exit();
    } else {
      echo "<script> alert('Wrong Password'); </script>";
    }
  } else {
    echo "<script> alert('User Not Registered'); </script>";
  }
}
?>
<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title>Doctor  Login</title>
  </head>
  <body>
    
    <link rel="stylesheet" type="text/css" href="style.css">
    <h2>Doctor Login</h2>
    <form action="" method="post" autocomplete="off">
      <label for="usernameid">Username or Doctor ID: </label>
      <input type="text" name="usernameid" id="usernameid" required value=""><br>
      <label for="password">Password: </label>
      <input type="password" name="password" id="password" required value=""><br>
      <button type="submit" name="submit">Login</button>
    </form>
    <br>
        <a href="welcome.html">Home</a>

  </body>
</html>


