<!DOCTYPE html>
<html lang="en" dir="ltr">
<head>
    <meta charset="utf-8">
    <title>Patient Search</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css">
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <div style="text-align: center; padding: 20px;">
        <h1>Patient Search</h1>
        <form action="" method="GET">
            <div style="display: flex; align-items: center; justify-content: center; max-width: 300px; margin: 0 auto; padding: 10px; border: 1px solid #ccc; border-radius: 4px;">
                <input type="text" name="search_query" placeholder="Enter patient ID or name" style="flex: 1; padding: 5px; border: none; outline: none;">
                <button type="submit" name="search" style="background: none; border: none; padding: 5px; cursor: pointer;">
                    <i class="fas fa-search" style="color: #555;"></i>
                </button>
            </div>
        </form>
    </div>

    <div style="text-align: center; padding: 20px;">
        <?php
        session_start();
        $conn = mysqli_connect("localhost", "root", "", "reglog");
        if (isset($_GET['search'])) {
            $searchQuery = $_GET['search_query'];

            // Perform the search query
            $query = "SELECT * FROM users WHERE id = '$searchQuery' OR name LIKE '$searchQuery%' AND Occupation='Patient'";
            $result = mysqli_query($conn, $query);

            // Display the search results
            if ($result && mysqli_num_rows($result) > 0) {
                echo "<h2>Search Results:</h2>";
                echo "<table style='margin: 0 auto; padding: 10px; border-collapse: collapse; width: 100%; background-color: yellow;'>";
                echo "<tr><th style='padding: 8px; color: white; border-bottom: 1px solid black; background-color: black;'>ID</th><th style='padding: 8px; background-color: black; color:white;border-bottom: 1px solid black;'>Name</th><th style='padding: 8px; background-color: black; color:white;border-bottom: 1px solid black;'>Email</th><th style='padding: 8px; border-bottom: 1px solid black;background-color: black; color:white'>Date of Birth</th></tr>";
                while ($row = mysqli_fetch_assoc($result)) {
                    $id = $row['id'];
                    $name = $row['name'];
                    $email = $row['email'];
                    $dob = $row['Date_of_Birth'];
                    echo "<tr><td style='padding: 8px; border-bottom: 1px solid black;'>$id</td><td style='padding: 8px; border-bottom: 1px solid black;'>$name</td><td style='padding: 8px; border-bottom: 1px solid black;'>$email</td><td style='padding: 8px; border-bottom: 1px solid black;' >$dob</td></tr>";
                }
                echo "</table>";
            } else {
                echo "<p>No matching patients found.</p>";
            }
        }
        ?>
        <a href="prescription.php">MAKE PRESCRIPTION</a>
    </div>
</body>
</html>
