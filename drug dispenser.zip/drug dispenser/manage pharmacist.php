          <!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <title>Dashboard</title>
  <link rel="stylesheet" href="style.css" />
  <!-- Font Awesome Cdn Link -->
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css"/>
</head>
<body>
  <div class="container">
    <nav>
      <ul>
        <li><a href="#" class="logo">
          <img src="http://localhost/Html/photo/admin.png" alt="">

          <span class="nav-item">WELCOME Admin</span>
        </a></li>
        <li><a href="#">
          <i class="fas fa-home"></i>
          <span class="nav-item">Home</span>
        </a></li>
        <li><a href="">
          <i class="fas fa-user"></i>
          <span class="nav-item">Profile</span>
        </a></li>
        <li><a href="manage doctors.php">
          <i class="fas fa-cross"></i>
          <span class="nav-item">Manage doctors</span>
        </a></li>
        <li><a href="manage.patients.php">
          <i class="fas fa-pills"></i>
          <span class="nav-item">Manage patients</span>
        </a></li>
        <li><a href="manage pharmacist.php">
          <i class="fas fa-user"></i>
          <span class="nav-item">Manage pharmacist</span>
        </a></li>
        <li><a href="add drugs.php">
          <i class="fas fa-cog"></i>
          <span class="nav-item">Add drugs</span>
        </a></li>
        <li><a href="manage drugs.php">
          <i class="fas fa-question-circle"></i>
          <span class="nav-item">Manage drugs</span>
        </a></li>
        <li><a href="" class="logout">
          <i class="fas fa-sign-out-alt"></i>
          <span class="nav-item">Log out</span>
        </a></li>
      </ul>
    </nav>

<?php
require_once("Config.php");

// Retrieve records
$sql = "SELECT * FROM users WHERE occupation = 'pharmacist'";
$result = $conn->query($sql);


if ($result->num_rows > 0) {
    echo "<table style='border-collapse: collapse; width: 100%; margin: 20px; background-color: yellow;'>";
    echo "<tr>";
    echo "<th style='border: 1px solid #ddd; padding: 8px; background-color: black; color: white;'>ID</th>";
    echo "<th style='border: 1px solid #ddd; padding: 8px; background-color: black; color: white;'>Name</th>";
    echo "<th style='border: 1px solid #ddd; padding: 8px; background-color: black; color: white;'>Username</th>";
    echo "<th style='border: 1px solid #ddd; padding: 8px; background-color: black; color: white;'>Email</th>";
    echo "<th style='border: 1px solid #ddd; padding: 8px; background-color: black; color: white;'>Password</th>";
    echo "<th style='border: 1px solid #ddd; padding: 8px; background-color: black; color: white;'>Occupation</th>";
    echo "<th style='border: 1px solid #ddd; padding: 8px; background-color: black; color: white;'>Actions</th>";
    echo "</tr>";
    while ($row = $result->fetch_assoc()) {
        echo "<tr>";
        echo "<td style='border: 1px solid #ddd; padding: 8px;'>" . $row['id'] . "</td>";
        echo "<td style='border: 1px solid #ddd; padding: 8px;'>" . $row['name'] . "</td>";
        echo "<td style='border: 1px solid #ddd; padding: 8px;'>" . $row['username'] . "</td>";
        echo "<td style='border: 1px solid #ddd; padding: 8px;'>" . $row['email'] . "</td>";
        echo "<td style='border: 1px solid #ddd; padding: 8px;'>" . $row['password'] . "</td>";
        echo "<td style='border: 1px solid #ddd; padding: 8px;'>" . $row['Occupation'] . "</td>";
        echo "<td style='border: 1px solid #ddd; padding: 8px;'>";
        echo "<a href='Update.php?id=" . $row['id'] . "' style='color: black; background-color: yellow; padding: 4px 8px; text-decoration: none;'>Edit</a> | ";
        echo "<a href='?delete_id=" . $row['id'] . "' style='color: black; background-color: yellow; padding: 4px 8px; text-decoration: none;'>Delete</a>";
        echo "</td>";
        echo "</tr>";
    }
    echo "</table>";
} else {
    echo "<p style='text-align: center;'>No data available</p>";
}

// Delete user if delete_id is provided
if (isset($_GET['delete_id'])) {
    $delete_id = $_GET['delete_id'];
    $sqlDelete = "DELETE FROM tb_user WHERE id='$delete_id'";
    if ($conn->query($sqlDelete) === TRUE) {
        echo "User deleted successfully.";
    } else {
        echo "Error deleting user: " . $conn->error;
    }
}

$conn->close();
?>
<br>
<a href="registration.php" style='display: inline-block; margin: 10px auto; padding: 8px 16px; background-color: yellow; color: white; text-decoration: none;'>Add User</a>
<link rel="stylesheet" type="text/css" href="style.css">
