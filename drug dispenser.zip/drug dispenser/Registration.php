<?php
require 'config.php';
if(!empty($_SESSION["id"])){

}
if(isset($_POST["submit"])){
  $name = $_POST["name"];
  $id = $_POST["id"];
  $username = $_POST["username"];
  $email = $_POST["email"];
  $Date_of_Birth=$_POST["Date_of_Birth"];
  $password = $_POST["password"];
  $confirmpassword = $_POST["confirmpassword"];
  $profilePicture = $_FILES["profile_picture"]["name"];  // Get the name of the uploaded file
 $profilePictureTmp = $_FILES["profile_picture"]["tmp_name"];  // Get the temporary file path

// Set the default profile picture if no file is uploaded
if (empty($profilePicture)) {
  $profilePicture = "default.avif";
} else {
  // Move the uploaded file to a desired location
  move_uploaded_file($profilePictureTmp, "profile_pictures/" . $profilePicture);
}

  $Occupation=$_POST["Occupation"];
  $duplicate = mysqli_query($conn, "SELECT * FROM users WHERE username = '$username' OR email = '$email'");
  if(mysqli_num_rows($duplicate) > 0){
    echo
    "<script> alert('Username or Email Has Already Taken'); </script>";
  }
  else{
    if($password == $confirmpassword){
      $query = "INSERT INTO users VALUES('$id','$name','$username','$email','$Date_of_Birth','$password','$Occupation','$profilePicture')";
      mysqli_query($conn, $query);
      echo
      "<script> alert('Registration Successful'); </script>";
      header("Location: Welcome.html");
    exit();
    }
    else{
      echo
      "<script> alert('Password Does Not Match'); </script>";
    }
  }
}
?>
<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
  
    <title>Registration</title>
     <link rel="stylesheet" type="text/css" href="Formstructure.css">
  </head>
  <body>
     <header>
    <div class="logo">
      <img src="profile_pictures\logo.jpeg" alt="Perfect Dose Logo">
      <h1>Perfect Dose LTD</h1>
      <br>
      
    </div>
    <nav>
      <ul>
        <li><a href="Home.php">Home</a></li>
        <li><a href="AboutUs.html">About Us</a></li>
        <li><a href="ContactUs.php">Contact Us</a></li>
        <li><a href="Welcome.html">Sign In</a></li>
      </ul>
    </nav>

  </header>
  <h2>Create Account</h2>
  <br>
  <div class="create-account">
  <div class="create-account-image">
    <img src="profile_pictures/Snake2.jpg" alt="Create Account Image">
  </div>
  <div class="create-account-content">
    
    <form class="" action="" method="post" enctype="multipart/form-data" autocomplete="off">
      <label for="name">Name : </label>
      <input type="text" name="name" id = "name" required value=""> <br>
      <label for="id" >Id:</label> 
      <input type="id" name="id" id = "id" required value=""> <br>
      <label for="username">Username : </label>
      <input type="text" name="username" id = "username" required value=""> <br>
      <label for="email">Email : </label>
      <input type="email" name="email" id = "email" required value=""> <br>
      <label for="dob">Date of Birth:</label>
      <input type="date" id="dob" name="Date_of_Birth"> <br>
      <label for="password">Password : </label>
      <input type="password" name="password" id = "password" required value=""> <br>
      <label for="confirmpassword">Confirm Password : </label>
      <input type="password" name="confirmpassword" id = "confirmpassword" required value=""> <br>
     <label for="Occupation"> Occupation :</label>
    <select name="Occupation" id="Occupation" required>
         <option value="Patient">Patient</option>
         <option value="Pharmacist">Pharmacist</option>
         <option value="Doctor">Doctor</option>
    </select><br>

    <label for="profile_picture">Profile Picture:</label>
     <input type="file" name="profile_picture" id="profile_picture"> <br>
   

    <button type="submit" name="submit">Register</button>
    </form>
       </div>
</div>
  
    
  </body>
</html>
