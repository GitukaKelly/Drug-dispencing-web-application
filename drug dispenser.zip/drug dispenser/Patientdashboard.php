


<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <title>Dashboard</title>
  <link rel="stylesheet" href="style.css" />
  <!-- Font Awesome Cdn Link -->
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css"/>
</head>
<body>
  <div class="container">
    <nav>
      <ul>
        <li><a href="#" class="logo">
          <img src="http://localhost/Html/photo/man.png" alt="">

          <span class="nav-item">WELCOME PATIENT 1</span>
        </a></li>
        <li><a href="#">
          <i class="fas fa-home"></i>
          <span class="nav-item">Home</span>
        </a></li>
        <li><a href="">
          <i class="fas fa-user"></i>
          <span class="nav-item">My prescriptions</span>
        </a></li>
        <li><a href="">
          <i class="fas fa-wallet"></i>
          <span class="nav-item">Medical history</span>
        </a></li>
        <li><a href="Home.php" class="logout">
          <i class="fas fa-sign-out-alt"></i>
          <span class="nav-item">Log out</span>
        </a></li>
      </ul>
    </nav>

    <section class="main">
      <div class="main-top">
        <h1>PERFECT DOSE</h1>
        <i class="fas fa-user-cog"></i>
      </div>
      <div class="main-skills">
        <div class="card">
          <i class="fas fa-user"></i>
          <h3>My profile</h3>
    
         <button><a href="manage profile.php">Manage profile</a></button>
        </div>
        <div class="card">
          <i class="fas fa-history"></i>
          <h3>Appointment history</h3>
          <button><a href="MyProfile.php">view history</a></button>
        </div>
        <div class="card">
          <i class="fas fa-pills"></i>
          <h3>Physician</h3>
        <button><a href="MyProfile.php">My doctor</a></button>
        </div>
      </div>
    </section>
  </div>
</body>
</html>
