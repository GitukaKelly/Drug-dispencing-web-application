

    
<?php
require('config.php');

// Retrieve prescriptions from the database
$sql_prescriptions = "SELECT p.prescription_id, p.name AS name, p.dose, p.Frequency, p.Days, p.quantity, p.patient_id, pt.patient_name, p.status, d.Price
                      FROM prescriptions p
                      INNER JOIN patient pt ON p.patient_id = pt.patient_id
                      INNER JOIN drug d ON p.name = d.name"; // Assuming there's a column named "name" in both "prescriptions" and "drug" tables
$result_prescriptions = $conn->query($sql_prescriptions);

// Handle Dispense action
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST["dispense"])) {
    $prescription_id = $_POST["prescription_id"];

    // Update the status of the prescription to "Dispensed"
    $sql_update_status = "UPDATE prescriptions SET status = 'Dispensed' WHERE prescription_id = $prescription_id";
    if ($conn->query($sql_update_status) === TRUE) {
        // Retrieve prescription data for inserting into history
        $sql_prescription_data = "SELECT * FROM prescriptions WHERE prescription_id = $prescription_id";
        $result_prescription_data = $conn->query($sql_prescription_data);
        $row_prescription_data = $result_prescription_data->fetch_assoc();

        // Insert prescription data into the history table
        $sql_insert_history = "INSERT INTO history (prescription_id, name, dose, Frequency, Days, quantity, patient_id, status)
                               VALUES ('{$row_prescription_data["prescription_id"]}', '{$row_prescription_data["name"]}', '{$row_prescription_data["dose"]}', '{$row_prescription_data["Frequency"]}', '{$row_prescription_data["Days"]}', '{$row_prescription_data["quantity"]}', '{$row_prescription_data["patient_id"]}', '{$row_prescription_data["status"]}')";

        if ($conn->query($sql_insert_history) === TRUE) {
            echo "drug dispensed successfully.";
        } else {
            echo "Error inserting into history table: " . $conn->error;
        }
    } else {
        echo "Error updating prescription status: " . $conn->error;
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <link rel="stylesheet" href="style.css">
    <title>Prescriptions Table</title>
    <style>
        table {
                margin: 20px;
                border-collapse: collapse;
                width: 100%;
                background-color: #f9f9f9;
            }
            th, td {
                padding: 10px;
                border: 1px solid #ddd;
            }
            th {
                background-color: #333;
                color: white;
            }
            tr:nth-child(even) {
                background-color: #f2f2f2;
            }
         </style>'
    </head>
<body>
      <h1>Prescriptions</h1>
    <?php
    
    if ($result_prescriptions->num_rows > 0) {
        echo "<table>";
        echo "<tr>";
        echo "<th>Prescription ID</th>";
        echo "<th>Drug Name</th>";
        echo "<th>Dose</th>";
        echo "<th>Frequency</th>";
        echo "<th>Days</th>";
        echo "<th>Quantity</th>";
        echo "<th>Patient ID</th>";
        echo "<th>Patient Name</th>";
        echo "<th>Price</th>"; // New column for "Price"
        echo "<th>Status</th>";
        echo "<th>Action</th>";
        echo "</tr>";
        
        while ($row = $result_prescriptions->fetch_assoc()) {
            echo "<tr>";
            echo "<td>".$row["prescription_id"]."</td>";
            echo "<td>".$row["name"]."</td>";
            echo "<td>".$row["dose"]."</td>";
            echo "<td>".$row["Frequency"]."</td>";
            echo "<td>".$row["Days"]."</td>";
            echo "<td>".$row["quantity"]."</td>";
            echo "<td>".$row["patient_id"]."</td>";
            echo "<td>".$row["patient_name"]."</td>";
            echo "<td>".$row["Price"]."</td>"; // Display the "Price" column value
            echo "<td>".$row["status"]."</td>";
            echo "<td>";

            if ($row["status"] == "Pending") {
                echo "<form method='post'>";
                echo "<input type='hidden' name='prescription_id' value='".$row["prescription_id"]."'>";
                echo "<input type='submit' name='dispense' value='Dispense'>";
                echo "</form>";
            }
            echo "</td>";
            echo "</tr>";
        }

        echo "</table>";
    } else {
        echo "No prescriptions found.";
    }


?>
</body>
</html>

