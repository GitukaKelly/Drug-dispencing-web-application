
 <?php
require_once("Config.php");

// Define the number of records to display per page
$recordsPerPage = 2;

// Calculate the total number of records
$sqlTotalRecords = "SELECT COUNT(*) AS total FROM tb_user";
$totalResult = $conn->query($sqlTotalRecords);
$totalRecords = $totalResult->fetch_assoc()['total'];

// Calculate the total number of pages
$totalPages = ceil($totalRecords / $recordsPerPage);

// Determine the current page number
$currentpage = isset($_GET['page']) ? $_GET['page'] : 1;

// Calculate the offset for retrieving records
$offset = ($currentpage - 1) * $recordsPerPage;

// Retrieve records for the current page
$sql = "SELECT * FROM tb_user LIMIT $offset, $recordsPerPage";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    echo "<table>";
    echo "<tr>";
    echo "<th>ID</th>";
    echo "<th>Name</th>";
    echo "<th>Username</th>";
    echo "<th>Email</th>";
    echo "<th>Password</th>";
    echo "<th>Occupation</th>";
    echo "<th>Actions</th>";
    echo "</tr>";
    while ($row = $result->fetch_assoc()) {
        echo "<tr>";
        echo "<td>" . $row['id'] . "</td>";
        echo "<td>" . $row['name'] . "</td>";
        echo "<td>" . $row['username'] . "</td>";
        echo "<td>" . $row['email'] . "</td>";
        echo "<td>" . $row['password'] . "</td>";
        echo "<td>" . $row['Occupation'] . "</td>";
        echo "<td>";
        echo "<a href='Update.php?id=" . $row['id'] . "'>Edit</a> | ";
        echo "<a href='?delete_id=" . $row['id'] . "'>Delete</a>";
        echo "</td>";
        echo "</tr>";
    }
    echo "</table>";

    // Generate pagination links
    echo "<br>";
    for ($i = 1; $i <= $totalPages; $i++) {
        $pageURL = "?page=" . $i;
        echo "<a href='" . $pageURL . "'>" . $i . "</a> ";
    }
} else {
    echo "<p>No data available</p>";
}

// Delete user if delete_id is provided
if (isset($_GET['delete_id'])) {
    $delete_id = $_GET['delete_id'];
    $sqlDelete = "DELETE FROM tb_user WHERE id='$delete_id'";
    if ($conn->query($sqlDelete) === TRUE) {
        echo "User deleted successfully.";
    } else {
        echo "Error deleting user: " . $conn->error;
    }
}

$conn->close();
?>
<br>
<a href="Registration.php"><button> Add User</button></a>
<link rel="stylesheet" type="text/css" href="style.css">
