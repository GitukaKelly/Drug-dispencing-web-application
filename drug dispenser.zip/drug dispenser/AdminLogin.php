<?php
require_once("Config.php");

// Handle login form submission
if ($_SERVER["REQUEST_METHOD"] == "POST") {
  $username = $_POST["username"];
  $password = $_POST["password"];

  // Validate username and password (You can modify this part according to your needs)
  if ($username === "admin" && $password === "admin98") {
    // Set session variables to indicate successful login
    $_SESSION["admin_logged_in"] = true;

    // Redirect to edit-delete.php
    header("Location: admindashboard.php");
    exit;
  } else {
    $loginError = "Invalid username or password.";
  }
}
?>

<!DOCTYPE html>
<html>
<head>
  <title> Adminstrator Login</title>
  <link rel="stylesheet" type="text/css" href="Logins.css">
</head>
<body>
  <h1>Administrator Login</h1>
  <header>
    <div class="logo">
      <img src="profile_pictures\logo.jpeg" alt="Perfect Dose Logo">
      <h1>Perfect Dose LTD</h1>
    </div>
    

    <nav >
      <ul>
        <li><a href="Home.php">Home</a></li>
        <li><a href="ContactUs.php">Contact</a></li>
        <li><a href="AboutUs.html">About Us</a></li>
        <li><a href="Registration.php">Sign Up</a></li>
        <li><a href="Welcome.html">Sign In</a></li>
      </ul>
    </nav>

  
  </header>
  <?php if (isset($loginError)): ?>
    <p><?php echo $loginError; ?></p>
  <?php endif; ?>
  <div class="login-container">
    <div class="login-box">
      <h1>Admin Login</h1>
      <form action="" method="post" autocomplete="" >
        <div class="input-group">
          <label for="username">Username </label>
          <input type="text" name="username" id="username" placeholder="Enter your username" required>
        </div>
        <div class="input-group">
          <label for="password">Password</label>
          <input type="password" name="password" id="password" placeholder="Enter your password" required>
        </div>
        <div class="remember-me">
          <input type="checkbox" name="remember" id="remember-me">
          <label for="remember-me">Remember Me</label>
        </div>
        <button type="submit" name="submit">Login</button>
      </form>
    </div>
  </div>
</body>
</html>
