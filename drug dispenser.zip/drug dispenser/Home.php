<!DOCTYPE html>
<html>
<head>
  <title>Perfect Dose - Drug Dispensing Tool</title>
  <link rel="stylesheet" type="text/css" href="test.css">
</head>
<body>
  <header>
    <div class="logo">
      <img src="profile_pictures\logo.jpeg" alt="Perfect Dose Logo">
      <h1>Perfect Dose LTD</h1>
    </div>
    

    <nav >
      <ul>
        <li><a href="Home.php">Home</a></li>
        <li><a href="ContactUs.php">Contact</a></li>
        <li><a href="AboutUs.html">About Us</a></li>
        <li><a href="Registration.php">Sign Up</a></li>
        <li><a href="Welcome.html">Sign In</a></li>
      </ul>
    </nav>
   

  </header>

   <section class="hero-section">
    <div class="hero-content">
      <h2>Welcome to Perfect Dose LTD</h2>
      <br>
      <p>   Your Health Our No. 1 Priority</p>
      <br>
      <a href="Registration.php" class="cta-button"> JOIN OUR COMMUNITY </a>
    </div>
  </section>
  <h4>Some of our partners include:</h4>
  <br>
  <section class="logos-section">
  <div class="logos-container">
    <img src="profile_pictures/download.jpeg" alt="Company 1 Logo">
    <img src="profile_pictures/strepsils.png" alt="Company 2 Logo">
    <img src="profile_pictures/piri.jpeg" alt="Company 3 Logo">
    <img src="profile_pictures/US anti.jpeg" alt="Company 3 Logo">
    <img src="profile_pictures/cipladon.jpeg" alt="Company 3 Logo">
    
  </div>
  <br class="br-line">
</section>
<section class="benefits-section">
  <div class="column">
    <h3>Why Choose Us?</h3>
    <p>We at Perfect Dose LTD Kenya are committed to offering the best madical services in the country and across the glob.We put the needs of our patients above our own as we are called to serve</p>
    <p>We accept most insuarance and have the most qualified physicians in the country.</p>
  </div>

  

  <div class="column">
    <h3>Our Services</h3>
    <p>We have state of the art facilities and have various branches across the contry to ensure we are easily reachable</p>
    <p>To join us register and come visit our offices for a check up and assignment of a primary physician</p>
  </div>
  
<br class="br-line">

</section>

<section class="feature-highlights">
  <div class="carousel">
    <div class="feature">
      <h3>Appointment Scheduling</h3>
      <p>Effortlessly schedule appointments with healthcare professionals online. Choose preferred dates and times that fit your schedule.</p>
    </div>
    <div class="feature">
      <h3>Electronic Medical Records (EMR)</h3>
      <p>Access and manage your electronic medical records securely. View medical history, test results, diagnoses, and treatment plans from anywhere.</p>
    </div>
    <div class="feature">
      <h3>Prescription Management</h3>
      <p>Streamline your medication management. Get electronic prescriptions, refill reminders, and easily track your medications.</p>
    </div>
  </div>
  <br class="br-line">
</section>

<section class="testimonials-certifications-section">
  <div class="testimonials-column">
    <h2>Patient Testimonials</h2>
    <div class="testimonials-container">
      <div class="testimonial">
        <p>"I had a great experience with Perfect Dose. The doctors were highly knowledgeable, caring, and attentive. They took the time to understand my concerns and provided the best treatment options. I highly recommend them!"</p>
        <span class="testimonial-author">- Sarah Johnson</span>
      </div>
      <div class="testimonial">
        <p>"I have been a patient at Perfect Dose for several years, and they have always exceeded my expectations. The entire staff is friendly and professional, and the facilities are top-notch. I feel confident in their expertise and trust them with my health."</p>
        <span class="testimonial-author">- Michael Thompson</span>
      </div>
    </div>
  </div>
  <div class="certifications-column">
    <h2>Certifications and Accreditations</h2>
    <div class="certifications-container">
      <img src="profile_pictures/cert1.jpeg" alt="Certification 1">
      <img src="profile_pictures/cert2.jpeg" alt="Certification 1">
      
      
    </div>
  </div>
  <br class="br-line">
</section>


<section class="social-media-section">
  <div class="social-media-icons">
    <a href="#" class="social-media-link">
      <img src="profile_pictures/facebook.jpeg" alt="Facebook">
    </a>
    <a href="#" class="social-media-link">
      <img src="profile_pictures/twitter.png" alt="Twitter">
    </a>
    <a href="#" class="social-media-link">
      <img src="profile_pictures/Instragam.jpeg" alt="Instagram">
    </a>
    <a href="#" class="social-media-link">
      <img src="profile_pictures/linkedin.png" alt="LinkedIn">
    </a>
  </div>

  <br class="br-line">
</section>

<footer>
  <div class="footer-container">
    <div class="footer-column">
      <h4>Useful Content</h4>
      <ul>
        <li><a href="#">Blog Articles</a></li>
        <li><a href="#">Recommendations</a></li>
        <li><a href="#">Tools and Tips</a></li>
      </ul>
    </div>
    <div class="footer-column">
      <h4>Company Updates</h4>
      <ul>
        <li><a href="#">Event Schedules</a></li>
        <li><a href="#">Product Launches</a></li>
        <li><a href="#">Announcements</a></li>
      </ul>
    </div>
    <div class="footer-column">
      <h4>Newsletter & Freebies</h4>
      <ul>
        <li><a href="#">Subscribe to Newsletter</a></li>
        <li><a href="#">Coupons</a></li>
        <li><a href="#">Free Medical Resources</a></li>
      </ul>
    </div>
  </div>
</footer>
<footer class="final-footer">
  <div class="footer-column">
    <h5>Contact Information</h5>
    <p>Email: PerfectDose@example.com</p>
    <p>Phone: +1 123-456-7890</p>
    <p>Address: 123 Main Street, Nakuru, Kenya</p>
  </div>
  <div class="footer-column">
    <h5>Address</h5>
    <p>123 Main Street</p>
    <p>Nakuru, Kenya</p>
  </div>
  <div class="footer-column">
    <p>&copy; 2023 Perfect Dose LTD</p>
  </div>
</footer>








 

 
</body>
</html>
