 <!DOCTYPE html>
<html>
<head>
  <title>Perfect Dose - Drug Dispensing Tool</title>
  <link rel="stylesheet" type="text/css" href="test.css">
</head>
<body>
  <header>
    <div class="logo">
      <img src="profile_pictures\logo.jpeg" alt="Perfect Dose Logo">
      <h1>Perfect Dose LTD</h1>
    </div>
    

    <nav >
      <ul>
        <li><a href="Home.php">Home</a></li>
        <li><a href="ContactUs.php">Contact</a></li>
        <li><a href="AboutUs.html">About Us</a></li>
        <li><a href="Registration.php">Sign Up</a></li>
        <li><a href="Welcome.html">Sign In</a></li>
      </ul>
    </nav>
     </header>
    </body>


 <?php
require_once("Config.php");

// Define the number of records to display per page
$recordsPerPage = 4;

// Calculate the total number of records
$sqlTotalRecords = "SELECT COUNT(*) AS total FROM users";
$totalResult = $conn->query($sqlTotalRecords);
$totalRecords = $totalResult->fetch_assoc()['total'];

// Calculate the total number of pages
$totalPages = ceil($totalRecords / $recordsPerPage);

// Determine the current page number
$currentpage = isset($_GET['page']) ? $_GET['page'] : 1;

// Calculate the offset for retrieving records
$offset = ($currentpage - 1) * $recordsPerPage;

// Retrieve records for the current page
$sql = "SELECT * FROM users LIMIT $offset, $recordsPerPage";
$result = $conn->query($sql);

echo "<img src='profile_pictures/Admin.png' alt='Admin Profile Picture' width='150' height='150' style='border-radius: 50%;'>";
echo "<h3>Welcome Admin</h3>";

if ($result->num_rows > 0) {
  echo "<table>";
  echo "<tr>";
  echo "<th colspan='8'>User List</th>";
  echo "</tr>";
  echo "<tr>";
  echo "<th>Profile Picture</th>";
  echo "<th>ID</th>";
  echo "<th>Name</th>";
  echo "<th>Username</th>";
  echo "<th>Email</th>";
  echo "<th>Password</th>";
  echo "<th>Occupation</th>";
  echo "<th>Actions</th>";
  echo "</tr>";
    while ($row = $result->fetch_assoc()) {
        echo "<tr>";
         echo "<td>";
        if (!empty($row['profile_picture'])) {
         echo "<img src='profile_pictures/" . $row['profile_picture'] . "' alt='Profile Picture' width='50' height='50' style='border-radius: 50%;'>";
         } else {
          echo "<img src='default.avif' alt='Default Profile Picture' width='50' height='50'style='border-radius:50%;'>";
           }
    echo "</td>";

         echo "<td>" . $row['id'] . "</td>";
        echo "<td>" . $row['name'] . "</td>";
        echo "<td>" . $row['username'] . "</td>";
        echo "<td>" . $row['email'] . "</td>";
        echo "<td>" . $row['password'] . "</td>";
        echo "<td>" . $row['Occupation'] . "</td>";
        echo "<td>";
        echo "<a href='UpdateTableReg.php?id=" . $row['id'] . "'>Edit</a> | ";
        echo "<a href='?delete_id=" . $row['id'] . "'>Delete</a>";
        echo "</td>";
        echo "</tr>";
    }
    echo "</table>";

    // Generate pagination links
    echo "<br>";
    for ($i = 1; $i <= $totalPages; $i++) {
        $pageURL = "?page=" . $i;
        echo "<a href='" . $pageURL . "'>" . $i . "</a> ";
    }
} else {
    echo "<p>No data available</p>";
}

// Delete user if delete_id is provided
if (isset($_GET['delete_id'])) {
    $delete_id = $_GET['delete_id'];
    $sqlDelete = "DELETE FROM users WHERE id='$delete_id'";
    if ($conn->query($sqlDelete) === TRUE) {
        echo "User deleted successfully.";
    } else {
        echo "Error deleting user: " . $conn->error;   }
}

$conn->close();
?>
<br>

<a href="Registration.php"><button type="submit" value="Add">Add User</button></a>
</html>





      
      

