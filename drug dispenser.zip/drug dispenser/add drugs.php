
<link rel ="stylesheet"href="style .css"/>
<?php
  // Define variables for form validation
  $drug_id = $name = $dose = $expiry_date = $pharmaceutical_co = '';

  // Define an array to store validation errors
  $errors = array();

  // Configure your database connection details
  $servername = "localhost";
  $username = "root";
  $password = '';
  $dbname = "reglog";

  // Create a new MySQLi instance
  $mysqli = new mysqli($servername, $username, $password, $dbname);

  // Check the connection
  if ($mysqli->connect_error) {
    die("Connection failed: " . $mysqli->connect_error);
  }

  if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Validate and sanitize the form data
    $drug_id = sanitize_input($_POST['drug_id']);
    $name = sanitize_input($_POST['name']);
    $dose = sanitize_input($_POST['dose']);
    $expiry_date = sanitize_input($_POST['expiry_date']);
    $pharmaceutical_co = sanitize_input($_POST['pharmaceutical_co']);
    $Price = sanitize_input($_POST['Price']);


    // Perform form validation
    if (empty($drug_id)) {
      $errors['drug_id'] = 'Drug ID is required.';
    }
    if (empty($name)) {
      $errors['name'] = 'Name is required.';
    }
    if (empty($dose)) {
      $errors['dose'] = 'Dose is required.';
    }
    if (empty($expiry_date)) {
      $errors['expiry_date'] = 'Expiry Date is required.';
    }
    if (empty($pharmaceutical_co)) {
      $errors['pharmaceutical_co'] = 'Pharmaceutical Co is required.';

    }
    if (empty($Price)) {
      $errors['price'] = 'Price is required.';
    }

    // If there are no validation errors, insert the data into the database
    if (empty($errors)) {
      $sql = "INSERT INTO drug (drug_id, name, dose, expiry_date, pharmaceutical_co,Price) VALUES ('$drug_id', '$name', '$dose', '$expiry_date', '$pharmaceutical_co','$Price')";

      if ($mysqli->query($sql) === true) {
        echo "Drug added successfully!";
      } else {
        echo "Error: " . $sql . "<br>" . $mysqli->error;
      }
    }
  }

  // Function to sanitize form inputs
  function sanitize_input($input) {
    $input = trim($input);
    $input = stripslashes($input);
    $input = htmlspecialchars($input);
    return $input;
  }
  ?>
  <link rel ="stylesheet"href="style .css"/>
  <html>
  <head>
    <title>Add Drug</title>
    <style>

      body {
        background-color: #f2f2f2;
        font-family: Arial, sans-serif;
      }
      
      h2 {
        text-align: center;
        margin: 20px 0;
      }
      
      form {
        width: 300px;
        margin: 0 auto;
        padding: 20px;
        border: 1px solid #ddd;
        background-color: #fff;
      }
      
      label {
        display: block;
        margin-bottom: 10px;
      }
      
      input[type="text"],
      input[type="date"] {
        width: 100%;
        padding: 8px;
        margin-bottom: 10px;
        border: 1px solid #ddd;
        box-sizing: border-box;
      }
      
      input[type="submit"] {
        background-color: #4CAF50;
        color: white;
        padding: 10px 20px;
        border: none;
        cursor: pointer;
      }
      
      input[type="submit"]:hover {
        background-color: #45a049;
      }
      
      .error-message {
        color: red;
        font-size: 14px;
      }
    </style>
  </head>
  <body>
   <?php
  // Define variables for form validation
  $drug_id = $name = $dose = $expiry_date = $pharmaceutical_co = $Price='';

  // Define an array to store validation errors
  $errors = array();

  // Configure your database connection details
  $servername = "localhost";
  $username = "root";
  $password = '';
  $dbname = "reglog";

  // Create a new MySQLi instance
  $mysqli = new mysqli($servername, $username, $password, $dbname);

  // Check the connection
  if ($mysqli->connect_error) {
    die("Connection failed: " . $mysqli->connect_error);
  }

  if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Validate and sanitize the form data
    $drug_id = sanitize_input($_POST['drug_id']);
    $name = sanitize_input($_POST['name']);
    $dose = sanitize_input($_POST['dose']);
    $expiry_date = sanitize_input($_POST['expiry_date']);
    $pharmaceutical_co = sanitize_input($_POST['pharmaceutical_co']);
    $Price=sanitize_input($_POST['Price']);

    // Perform form validation
    if (empty($drug_id)) {
      $errors['drug_id'] = 'Drug ID is required.';
    }
    if (empty($name)) {
      $errors['name'] = 'Name is required.';
    }
    if (empty($dose)) {
      $errors['dose'] = 'Dose is required.';
    }
    if (empty($expiry_date)) {
      $errors['expiry_date'] = 'Expiry Date is required.';
    }
    if (empty($pharmaceutical_co)) {
      $errors['pharmaceutical_co'] = 'Pharmaceutical Co is required.';
    }
    if (empty($Price)) {
      $errors['Price'] = 'Price is required.';
    }

    // If there are no validation errors, insert the data into the database
    if (empty($errors)) {
      $sql = "INSERT INTO drug (drug_id, name, dose, expiry_date, pharmaceutical_co,Price) VALUES ('$drug_id', '$name', '$dose', '$expiry_date', '$pharmaceutical_co','$Price')";

      if ($mysqli->query($sql) === true) {
        echo "Drug added successfully!";
      } else {
        
      }
    }
  }

 
  ?>
  <link rel ="stylesheet"href="style .css"/>
  <html>
  <head>
    <title>Add Drug</title>
    <style>
      body {

        background-color: #f2f2f2;
        font-family: Arial, sans-serif;
      }
      
      h2 {
        text-align: center;
        margin: 20px 0;
      }
      
      form {
        width: 300px;
        margin: 0 auto;
        padding: 20px;
        border: 1px solid #ddd;
        background-color: #fff;
      }
      
      label {
        display: block;
        margin-bottom: 10px;
      }
      
      input[type="text"],
      input[type="date"] {
        width: 100%;
        padding: 8px;
        margin-bottom: 10px;
        border: 1px solid #ddd;
        box-sizing: border-box;
      }
      
      input[type="submit"] {
        background-color: #4CAF50;
        color: white;
        padding: 10px 20px;
        border: none;
        cursor: pointer;
      }
      
      input[type="submit"]:hover {
        background-color: #45a049;
      }
      
      .error-message {
        color: red;
        font-size: 14px;
      }
    </style>
    <link rel ="stylesheet"href="style .css"/>
  </head>
  <body>

    <h2>Add Drug</h2>
    <form action="<?php echo htmlspecialchars($_SERVER['PHP_SELF']); ?>" method="POST">
      <label for="drug_id">Drug ID:</label>
      <input type="text" id="drug_id" name="drug_id" value="<?php echo $drug_id; ?>" required>
      <?php if (isset($errors['drug_id'])) echo "<p class='error-message'>" . $errors['drug_id'] . "</p>"; ?><br>

      <label for="name">Name:</label>
      <input type="text" id="name" name="name" value="<?php echo $name; ?>" required>
      <?php if (isset($errors['name'])) echo "<p class='error-message'>" . $errors['name'] . "</p>"; ?><br>

      <label for="dose">Dose:</label>
      <input type="text" id="dose" name="dose" value="<?php echo $dose; ?>" required>
      <?php if (isset($errors['dose'])) echo "<p class='error-message'>" . $errors['dose'] . "</p>"; ?><br>

      <label for="expiry_date">Expiry Date:</label>
      <input type="date" id="expiry_date" name="expiry_date" value="<?php echo $expiry_date; ?>" required>
      <?php if (isset($errors['expiry_date'])) echo "<p class='error-message'>" . $errors['expiry_date'] . "</p>"; ?><br>

      <label for="pharmaceutical_co">Pharmaceutical Co:</label>
      <input type="text" id="pharmaceutical_co" name="pharmaceutical_co" value="<?php echo $pharmaceutical_co; ?>" required>
      <?php if (isset($errors['pharmaceutical_co'])) echo "<p class='error-message'>" . $errors['pharmaceutical_co'] . "</p>"; ?><br>
      <label for="price">Price:</label>
      <input type="text" id="price" name="Price" value="<?php echo $Price; ?>" required>
      <?php if (isset($errors['price'])) echo "<p class='error-message'>" . $errors['price'] . "</p>"; ?><br>


      <input type="submit" value="Add Drug">
    </form>
  </body>
  </html>

