<?php
require 'config.php';

if (isset($_POST["submit"])) {
  $Name = $_POST["Name"];
  $Email = $_POST["Email"];
  $Subject = $_POST["Subject"];
  $Message = $_POST["Message"];

  // Insert the form data into the database table
  $query = "INSERT INTO contactus (Name, Email, Subject, Message) VALUES ('$Name', '$Email', '$Subject', '$Message')";
  mysqli_query($conn, $query);

  // Redirect to a thank you page or display a success message
  header("Location: thankyou.html");
  exit();
}
?>

<!DOCTYPE html>
<html lang="en" dir="ltr">
<head>
  <meta charset="utf-8">
  <title>Contact Us</title>
  <link rel="stylesheet" type="text/css" href="ContactUs.css">
</head>
<body>
  <header>
    <div class="logo">
      <img src="profile_pictures\logo.jpeg" alt="Perfect Dose Logo">
      <h1>Perfect Dose LTD</h1>
    </div>
    <nav>
      <ul>
        <li><a href="Home.php">Home</a></li>
        <li><a href="AboutUs.html">About Us</a></li>
        <li><a href="Registration.php">Sign Up</a></li>
        <li><a href="Welcome.html">Sign In</a></li>
      </ul>
    </nav>
  </header>
  
  <div class="container">
    <h1>INQUIRIES FORM</h1>
    <div class="text-container">
      <p class="text">If you have any inquiry, please fill out the inquiry form below or email us at PerfectDose@gmail.com</p>
      <p class="text">Our location: Fifth floor, Sawa Mall. Appointments and Walk-ins welcome.</p>
      <p>Your Health is our number one priority</p>
    </div>
    <form method="post" class="contact-form">
      <div class="form-column">
        <label for="name">Name:</label>
        <input type="text" id="Name" name="Name" required>
        <label for="email">Email:</label>
        <input type="email" id="Email" name="Email" required>
      </div>
      <div class="form-column">
        <label for="subject">Subject:</label>
        <input type="text" id="Subject" name="Subject" required>
        <label for="message">Message:</label>
        <textarea id="Message" name="Message" required></textarea>
      </div>

       </div>

       <div class="button-container">

      <button type="submit" name="submit">Submit Inquiry</button>
      </div>
      

    </form>
 
 
</body>
</html>
