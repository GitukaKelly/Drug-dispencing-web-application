<!DOCTYPE html>
<html>
<head>
  <link rel="stylesheet" type="text/css" href="styles.css">
</head>
<body>
  <div class="dashboard">
    <aside class="sidebar">
      <ul class="navbar">
        <li><a href="patients.php">Patients</a></li>
        <li><a href="appointments.php">Appointments</a></li>
        <li><a href="prescriptions.php">Prescriptions</a></li>
      </ul>
    </aside>

    <header>
      <?php
      // Start the session
      session_start();

      // Check if the user is logged in
      if (isset($_SESSION['doctor_id'])) {
        $doctorId = $_SESSION['doctor_id'];

        // Database connection and doctor information retrieval
        // ...

        // Fetch the doctor's profile information from the database using $doctorId
        // ...
      }
      ?>

      <div class="profile">
        <img src="<?php echo $profilePicture; ?>" alt="Doctor Profile Picture">
        <div class="profile-info">
          <h2><?php echo $name; ?></h2>
          <p>Speciality: <?php echo $speciality; ?></p>
          <p>Age: <?php echo $age; ?></p>
          <p>Email: <?php echo $email; ?></p>
        </div>
      </div>
    </header>

    <main>
      <div class="content">
        <h1>Welcome to the Dashboard!</h1>
        <p>Select an option from the sidebar to view:</p>
      </div>
    </main>
  </div>
</body>
</html>
