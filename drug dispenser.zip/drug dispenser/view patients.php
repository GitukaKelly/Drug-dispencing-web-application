<?php
require_once("Config.php");

// Retrieve records
$sql = "SELECT * FROM users WHERE occupation = 'patient'";
$result = $conn->query($sql);

echo "<table style='border-collapse: collapse; width: 100%; margin: 20px; background-color:#FFCC66;'>";
echo "<tr>";
echo "<th style='border: 1px solid #ddd; padding: 8px;'>ID</th>";
echo "<th style='border: 1px solid #ddd; padding: 8px;'>Name</th>";
echo "<th style='border: 1px solid #ddd; padding: 8px;'>Username</th>";
echo "<th style='border: 1px solid #ddd; padding: 8px;'>Email</th>";
echo "<th style='border: 1px solid #ddd; padding: 8px;'>Occupation</th>";
echo "</tr>";

if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        echo "<tr>";
        echo "<td style='border: 1px solid #ddd; padding: 8px;'>" . $row['id'] . "</td>";
        echo "<td style='border: 1px solid #ddd; padding: 8px;'>" . $row['name'] . "</td>";
        echo "<td style='border: 1px solid #ddd; padding: 8px;'>" . $row['username'] . "</td>";
        echo "<td style='border: 1px solid #ddd; padding: 8px;'>" . $row['email'] . "</td>";
        echo "<td style='border: 1px solid #ddd; padding: 8px;'>" . $row['Occupation'] . "</td>";
        echo "</tr>";
    }
} else {
    echo "<tr>";
    echo "<td colspan='6' style='border: 1px solid #ddd; padding: 8px; text-align: center;'>No data available</td>";
    echo "</tr>";
}

echo "</table>";

$conn->close();
?>
<link rel="stylesheet" type="text/css" href="style.css">