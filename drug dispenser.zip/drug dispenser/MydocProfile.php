<?php
// Start the session
session_start();

// Check if the user is logged in
if (!isset($_SESSION['user'])) {
    // Redirect to the login page if the user is not logged in
    header("Location: login.php");
    exit();
}

// Get the user data from the session
$user = $_SESSION['user'];

// Connect to the database and retrieve the user's profile information
require_once("Config.php");

// Retrieve user profile information from the database
$sql = "SELECT * FROM tb_user WHERE id = " . $user['id'];
$result = $conn->query($sql);
if ($result->num_rows > 0) {
    $profile = $result->fetch_assoc();
} else {
    // Handle the case when the user's profile is not found in the database
    echo "User profile not found.";
    exit();
}

// Handle profile update form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Retrieve the updated profile information from the form
    $updatedProfile = [
        'username' => $_POST['username'],
        'id' => $_POST['id'],
        'email' => $_POST['email'],
        'occupation' => $_POST['occupation']
        // Add more fields if needed
    ];

    // Update the profile information in the database
    $sqlUpdate = "UPDATE tb_user SET username = '{$updatedProfile['username']}', email = '{$updatedProfile['email']}', occupation = '{$updatedProfile['occupation']}' WHERE id = " . $user['id'];
    if ($conn->query($sqlUpdate) === TRUE) {
        // Update the session with the updated profile information
        $_SESSION['user'] = array_merge($user, $updatedProfile);
        echo "Profile updated successfully.";
    } else {
        echo "Error updating profile: " . $conn->error;
    }
}

$conn->close();
?>

<!DOCTYPE html>
<html>
<head>
    <title>View Profile</title>
    <link rel="stylesheet" type="text/css" href="style.css">
</head>
<body>
    <div class="profile">
        <h1>View Profile</h1>
        <div class="profile-info">
            <div class="profile-picture">
                <?php
                // Display the profile picture
                // Assuming the profile picture file path is stored in $profile['picture']
                echo "<img src='{$profile['picture']}' alt='Profile Picture'>";
                ?>
            </div>
            <div class="profile-details">
                <table>
                    <tr>
                        <td>ID:</td>
                        <td><?php echo $profile['id']; ?></td>
                    </tr>
                    <tr>
                        <td>Username:</td>
                        <td><?php echo $profile['username']; ?></td>
                    </tr>
                    <tr>
                        <td>Email:</td>
                        <td><?php echo $profile['email']; ?></td>
                    </tr>
                    <tr>
                        <td>Occupation:</td>
                        <td><?php echo $profile['occupation']; ?></td>
                    </tr>
                    <!-- Add more fields if needed -->
                </table>
            </div>
        </div>
        <div class="update-profile">
            <h2>Update Profile</h2>
            <form method="POST" action="">
                <label>Id:</label>
                <input type="text" name="id" value="<?php echo $profile['id']; ?>"><br>
                <label>Username:</label>
                <input type="text" name="username" value="<?php echo $profile['username']; ?>"><br>
                <label>Email:</label>
                <input type="email" name="email" value="<?php echo $profile['email']; ?>"><br>
                <label>Occupation:</label>
                <input type="text" name="occupation" value="<?php echo $profile['occupation']; ?>"><br>
                <!-- Add more fields if needed -->
                <input type="submit" value="Update Profile">
            </form>
        </div>
    </div>
</body>
</html>
