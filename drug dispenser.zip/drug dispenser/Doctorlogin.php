<?php

require 'config.php';

if (isset($_POST["submit"])) {
  $usernameid = $_POST["usernameid"];
  $password = $_POST["password"];

  $result = mysqli_query($conn, "SELECT * FROM users WHERE Occupation='Doctor' AND (username = '$usernameid' OR id = '$usernameid')");

  if (mysqli_num_rows($result) > 0) {
    $row = mysqli_fetch_assoc($result);
    if ($password == $row['password']) {
      $_SESSION["login"] = true;
      $_SESSION["id"] = $row["id"];
      header("Location: docdashboard.php");
      exit();
    } else {
      echo "<script> alert('Wrong Password'); </script>";
    }
  } else {
    echo "<script> alert('User Not Registered'); </script>";
  }
}
?>
<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title>Doctor Login</title>
    <link rel="stylesheet" type="text/css" href="Logins.css">
  </head>

  <body>
    <header>
    <div class="logo">
      <img src="profile_pictures\logo.jpeg" alt="Perfect Dose Logo">
      <h1>Perfect Dose LTD Company</h1>
    </div>
    

    <nav >
      <ul>
        <li><a href="Home.php">Home</a></li>
        <li><a href="ContactUs.php">Contact</a></li>
        <li><a href="AboutUs.html">About Us</a></li>
        <li><a href="Registration.php">Sign Up</a></li>
        <li><a href="Welcome.html">Sign In</a></li>
      </ul>
    </nav>

  
  </header>

    <div class="login-container">
    <div class="login-box">
      <h1>Doctor Login</h1>
      <form action="" method="post" autocomplete="" >
        <div class="input-group">
          <label for="usernameid">Username or Doctor ID</label>
          <input type="text" name="usernameid" id="usernameid" placeholder="Enter your username or Id" required>
        </div>
        <div class="input-group">
          <label for="password">Password</label>
          <input type="password" name="password" id="password" placeholder="Enter your password" required>
        </div>
        <div class="remember-me">
          <input type="checkbox" name="remember" id="remember-me">
          <label for="remember-me">Remember Me</label>
        </div>
        <button type="submit" name="submit">Login</button>
      </form>
    </div>
  </div>
  </body>
</html>
