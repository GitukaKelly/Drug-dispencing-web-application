
<link rel="stylesheet"href="style.css"/>
<?php
session_start();
$conn = mysqli_connect("localhost", "root", "", "reglog");

if (isset($_SESSION["id"])) {
    $doctor_id = $_SESSION["id"];
    
    // Fetch the doctor's profile data using the retrieved doctor ID
    $query = "SELECT u.name, u.email, u.username,d.Experience, d.Speciality,
              TIMESTAMPDIFF(YEAR, u.Date_of_Birth, CURDATE()) AS age
              FROM users AS u
              JOIN doctors AS d ON u.id = d.user_id
              WHERE u.Occupation = 'Doctor' AND u.id = $doctor_id";
    
    $result = $conn->query($query);
    
    // Check if the query executed successfully and retrieve the data
    if ($result && $result->num_rows > 0) {
        $row = $result->fetch_assoc();
        $name = $row['name'];
        $email = $row['email'];
        $username = $row['username'];
        $experience = $row['Experience'];
        $speciality = $row['Speciality'];
        $age = $row['age'];
    
        // Display the doctor's profile information using HTML
        ?>
        <div class="profile">
            <div class="profile-picture">
                <img src="http://localhost/drugDIspenser/photo/logo.jpg" alt="" style="border-radius: 50%; width: 150px; height: 150px;">
            </div>
            <div class="profile-details">
                <h2><?php echo $username; ?></h2>
                <p>Name: <?php echo $name; ?></p>
                <p>Email: <?php echo $email; ?></p>
                <p>Age: <?php echo $age; ?></p>
                <p>Experience: <?php echo $experience; ?> years</p>
                <p>Speciality: <?php echo $speciality; ?></p>
            </div>
        </div>
        <?php
    } else {
        echo "No profile found.";
    }
} else {
    echo "Invalid session. Please log in.";
}

// Close the database connection
$conn->close();
?>
