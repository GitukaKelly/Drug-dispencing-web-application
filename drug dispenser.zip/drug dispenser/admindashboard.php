          <!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <title>Dashboard</title>
  <link rel="stylesheet" href="style.css" />
  <!-- Font Awesome Cdn Link -->
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css"/>
</head>
<body>
  <div class="container">
    <nav>
      <ul>
        <li><a href="#" class="logo">
          <img src="http://localhost/Html/photo/admin.png" alt="">

          <span class="nav-item">WELCOME Admin</span>
        </a></li>
        <li><a href="#">
          <i class="fas fa-home"></i>
          <span class="nav-item">Home</span>
        </a></li>
        <li><a href="">
          <i class="fas fa-user"></i>
          <span class="nav-item">Profile</span>
        </a></li>
        <li><a href="manage doctors.php">
          <i class="fas fa-cross"></i>
          <span class="nav-item">Manage doctors</span>
        </a></li>
        <li><a href="manage.patients.php">
          <i class="fas fa-pills"></i>
          <span class="nav-item">Manage patients</span>
        </a></li>
        <li><a href="manage pharmacist.php">
          <i class="fas fa-user"></i>
          <span class="nav-item">Manage pharmacist</span>
        </a></li>
        <li><a href="add drugs.php">
          <i class="fas fa-cog"></i>
          <span class="nav-item">Add drugs</span>
        </a></li>
        <li><a href="manage drugs.php">
          <i class="fas fa-question-circle"></i>
          <span class="nav-item">Manage drugs</span>
        </a></li>
        <li><a href="Home.php" class="logout">
          <i class="fas fa-sign-out-alt"></i>
          <span class="nav-item">Log out</span>
        </a></li>
      </ul>
    </nav>

    <section class="main">
      <div class="main-top">
        <h1>PERFECT DOSE</h1>
        <i class="fas fa-user-cog"></i>
      </div>
      <div class="main-skills">
        <div class="card">
          <i class="fas fa-pills"></i>
          <h3>Patients</h3>
         <button><a href="view patients.php">View Patients</a></button>

        </div>
        <div class="card">
          <i class="fas fa-cross"></i>
          <h3>Doctors</h3>
         <button><a href="view doctors.php">View doctors</a></button>

        </div>
        <div class="card">
          <i class="fas fa-user"></i>
          <h3>Pharmacists</h3>
<button><a href="view pharmacist.php">View Pharmacists</a></button>

        </div>
        <div class="card">
          <i class="fas fa-home"></i>
          <h3>Inventory</h3>
         <button><a href="Inventory.php">View inventory</a></button>

        </div>
      </div>
    </section>
  </div>
</body>
</html>


