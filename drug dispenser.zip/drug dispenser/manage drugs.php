<?php
require_once("config.php");

// Retrieve records
$sql = "SELECT * FROM drug";
$result = $conn->query($sql);

echo "<table style='border-collapse: collapse; width: 100%; margin: 20px; background-color: yellow;'>";
echo "<tr>";
echo "<th style='border: 1px solid #ddd; padding: 8px; background-color: black; color: white;'>Drug ID</th>";
echo "<th style='border: 1px solid #ddd; padding: 8px; background-color: black; color: white;'>Drug name</th>";

echo "<th style='border: 1px solid #ddd; padding: 8px; background-color: black; color: white;'>Dose</th>";
echo "<th style='border: 1px solid #ddd; padding: 8px; background-color: black; color: white;'>Expiry Date</th>";
echo "<th style='border: 1px solid #ddd; padding: 8px; background-color: black; color: white;'>Pharmaceutical Co</th>";
echo "<th style='border: 1px solid #ddd; padding: 8px; background-color: black; color: white;'>Actions</th>";
echo "</tr>";

if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        echo "<tr>";
        echo "<td style='border: 1px solid #ddd; padding: 8px;'>" . $row['drug_id'] . "</td>";
         echo "<td style='border: 1px solid #ddd; padding: 8px;'>" . $row['name'] . "</td>";
        echo "<td style='border: 1px solid #ddd; padding: 8px;'>" . $row['dose'] . "</td>";
        echo "<td style='border: 1px solid #ddd; padding: 8px;'>" . $row['expiry_date'] . "</td>";
        echo "<td style='border: 1px solid #ddd; padding: 8px;'>" . $row['pharmaceutical_co'] . "</td>";
        echo "<td style='border: 1px solid #ddd; padding: 8px;'>";
        echo "<a href='Update.php?id=" . $row['drug_id'] . "' style='color: black; background-color: yellow;; padding: 4px 8px; text-decoration: none;'>Edit</a> | ";
        echo "<a href='?delete_id=" . $row['drug_id'] . "' style='color: black; background-color: yellow; padding: 4px 8px; text-decoration: none;'>Delete</a>";
        echo "</td>";
        echo "</tr>";
    }
} else {
    echo "<tr>";
    echo "<td colspan='5' style='border: 1px solid #ddd; padding: 8px; text-align: center;'>No data available</td>";
    echo "</tr>";
}

echo "</table>";

// Delete drug if delete_id is provided
if (isset($_GET['delete_id'])) {
    $delete_id = $_GET['delete_id'];
    $sqlDelete = "DELETE FROM drugs WHERE drug_id='$delete_id'";
    if ($conn->query($sqlDelete) === TRUE) {
        echo "Drug deleted successfully.";
    } else {
        echo "Error deleting drug: " . $conn->error;
    }
}

$conn->close();
?>
<br>
<a href="add drugs.php" style='display: inline-block; margin-top: 5px; padding: 8px 10px; background-color: black; color: yellow; text-decoration: italic;'>ADD DRUG</a>
<link rel="stylesheet" type="text/css" href="style.css">
