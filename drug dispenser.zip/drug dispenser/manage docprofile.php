          <!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <title>Dashboard</title>
  <link rel="stylesheet" href="style.css" />
  <!-- Font Awesome Cdn Link -->
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css"/>
</head>
<body>
  <div class="container">
    <nav>
      <ul>
        <li><a href="#" class="logo">
          <img src="http://localhost/Html/photo/admin.png" alt="">

          <span class="nav-item">WELCOME Admin</span>
        </a></li>
        <li><a href="#">
          <i class="fas fa-home"></i>
          <span class="nav-item">Home</span>
        </a></li>
        <li><a href="">
          <i class="fas fa-user"></i>
          <span class="nav-item">Profile</span>
        </a></li>
        <li><a href="manage doctors.php">
          <i class="fas fa-cross"></i>
          <span class="nav-item">Manage doctors</span>
        </a></li>
        <li><a href="manage.patients.php">
          <i class="fas fa-pills"></i>
          <span class="nav-item">Manage patients</span>
        </a></li>
        <li><a href="manage pharmacist.php">
          <i class="fas fa-user"></i>
          <span class="nav-item">Manage pharmacist</span>
        </a></li>
        <li><a href="add drugs.php">
          <i class="fas fa-cog"></i>
          <span class="nav-item">Add drugs</span>
        </a></li>
        <li><a href="manage drugs.php">
          <i class="fas fa-question-circle"></i>
          <span class="nav-item">Manage drugs</span>
        </a></li>
        <li><a href="" class="logout">
          <i class="fas fa-sign-out-alt"></i>
          <span class="nav-item">Log out</span>
        </a></li>
      </ul>
    </nav>

<?php
require 'config.php';

if (empty($_SESSION["id"])) {
    exit;
}

if (isset($_POST["submit"])) {
    $id = $_SESSION["id"];
    $name = $_POST["name"];
    $username = $_POST["username"];
    $email = $_POST["email"];
    $password = $_POST["password"];
    $confirmpassword = $_POST["confirmpassword"];
    $photo = $_FILES["photo"]["name"];
    $photoTmp = $_FILES["photo"]["tmp_name"];

    if (empty($photo)) {
        $photo = "default.png";
    } else {
        move_uploaded_file($photoTmp, "photo/" . $photo);
    }

    $Occupation = $_POST["Occupation"];

    $query = "UPDATE tb_user SET name = '$name', username = '$username', email = '$email', password = '$password', occupation = '$Occupation', photo = '$photo' WHERE id = '$id'";
    
    if ($password == $confirmpassword) {
        if (mysqli_query($conn, $query)) {
            echo "<script> alert('Profile Updated Successfully'); </script>";
        } else {
            echo "<script> alert('Failed to update profile. Please try again.'); </script>";
        }
    } else {
        echo "<script> alert('Password Does Not Match'); </script>";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <title>Doctr | Edit User Profile</title>
</head>
<body>
    <div class="main-content">
        <div class="container">
            <h2>Edit User Profile</h2>
            <form method="post" enctype="multipart/form-data" autocomplete="off">
                <label for="name">Name:</label>
                <input type="text" name="name" id="name" required value=""><br>

                <label for="username">Username:</label>
                <input type="text" name="username" id="username" required value=""><br>

                <label for="email">Email:</label>
                <input type="email" name="email" id="email" required value=""><br>

                <label for="password">Password:</label>
                <input type="password" name="password" id="password" required value=""><br>

                <label for="confirmpassword">Confirm Password:</label>
                <input type="password" name="confirmpassword" id="confirmpassword" required value=""><br>

                <label for="Occupation">Occupation:</label>
                <select name="Occupation" id="Occupation" required>
                    <option value="Patient">Patient</option>
                    <option value="Pharmacist">Pharmacist</option>
                    <option value="Doctor">Doctor</option>
                </select><br>

                <label for="photo">Profile Picture:</label>
                <input type="file" name="photo" id="photo"><br>

                <button type="submit" name="submit">Update</button>
            </form>
        </div>
    </div>
</body>
</html>
