
  <!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <title>Dashboard</title>
  <link rel="stylesheet" href="style.css" />
  <!-- Font Awesome Cdn Link -->
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css"/>
</head>
<body>
  <div class="container">
    <nav>
      <ul>
        <li><a href="#" class="logo">
          <img src="http://localhost/Html/photo/doc.jpg" alt="">

          <span class="nav-item">WELCOME DOCTOR</span>
        </a></li>
        <li><a href="#">
          <i class="fas fa-home"></i>
          <span class="nav-item">Home</span>
        </a></li>
        <li><a href="view patients.php">
          <i class="fas fa-user"></i>
          <span class="nav-item">View patients</span>
        </a></li>
        <li><a href="view patients.php">
          <i class="fas fa-wallet"></i>
          <span class="nav-item">My Patients</span>
           </a></li>
          <li><a href="search.php">
          <i class="fas fa-question-circle"></i>
          <span class="nav-item">search</span>
        </a></li>
      

        <li><a href="Home.php" class="logout">
        <i class="fas fa-sign-out-alt"></i>
          <span class="nav-item">Log out</span>
        </a></li>
      </ul>
    </nav>

    <section class="main">
      <div class="main-top">
        <h1>PERFECT DOSE</h1>
        <i class="fas fa-user-cog"></i>
      </div>
      <div class="main-skills">
        <div class="card">
          <i class="fas fa-user"></i>
          <h3>My profile</h3>
    
        
<button><a href="ViewDocProfile.php">view profile</a></button>
        </div>
        <div class="card">
          <i class="fas fa-history"></i>
          <h3>Appointments history</h3>
          
        <button><a href="MyProfile.php">view history</a></button>
        </div>
        <div class="card">
          <i class="fas fa-pills"></i>
          <h3>Make prescription</h3>
        <button><a href="prescription.php">Prescribe drugs</a></button>
        </div>
      </div>
    </section>
  </div>
</body>
</html>
