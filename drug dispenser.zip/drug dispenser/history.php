<<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title></title>
    <link rel="stylesheet" type="text/css" href="style.css">
</head>
<body>
    <h2>Dispensing history<h2>

</body>
</html>


<?php
require('config.php');

// Assuming you have already established a database connection
$conn = mysqli_connect("localhost", "root", '', "reglog");

// Retrieve history information including the patient name and prescription name using SQL JOIN
$sql = "SELECT h.drug_id, h.name, h.dose, h.Frequency, h.Days, h.quantity, h.patient_id, p.patient_name, pr.name AS prescription_name, h.status
        FROM history h
        JOIN patient p ON h.patient_id = p.patient_id
        JOIN prescriptions pr ON h.patient_id = pr.patient_id";

// Execute the query
$result = mysqli_query($conn, $sql);

if (!$result) {
    // Handle the error
    echo "Error: " . mysqli_error($conn);
} else {
    // Display the history table with styling
    echo '<style>
            table {
                margin: 20px;
                border-collapse: collapse;
                width: 100%;
                background-color: #f9f9f9;
            }
            th, td {
                padding: 10px;
                border: 1px solid #ddd;
            }
            th {
                background-color: #333;
                color: white;
            }
            tr:nth-child(even) {
                background-color: #f2f2f2;
            }
         </style>';

    echo '<table>
            
                 <th>Prescription Name</th>
                 <th>Dose</th>
                <th>Frequency</th>
                <th>Days</th>
                <th>Quantity</th>
                <th>Patient ID</th>
                <th>Patient Name</th>
                <th>Status</th>
            </tr>';

    // Loop through the result set
    while ($row = mysqli_fetch_assoc($result)) {
       
        $dose = $row['dose'];
        $Frequency = $row['Frequency'];
        $Days = $row['Days'];
        $quantity = $row['quantity'];
        $patient_id = $row['patient_id'];
        $patient_name = $row['patient_name'];
        $prescription_name = $row['prescription_name'];
        $status = $row['status'];

        echo "<tr>
                 <td>$prescription_name</td>
                <td>$dose</td>
                <td>$Frequency</td>
                <td>$Days</td>
                <td>$quantity</td>
                <td>$patient_id</td>
                <td>$patient_name</td>
            
                <td>$status</td>
            </tr>";
    }

    echo '</table>';
}
?>
