<?php
require('config.php');

// Retrieve prescriptions from the database
$sql_prescriptions = "SELECT p.prescription_id, p.name AS drug_name, p.dose, p.Frequency, p.Days, p.quantity, p.patient_id, pt.patient_name
                      FROM prescriptions p
                      INNER JOIN patient pt ON p.patient_id = pt.patient_id";
$result_prescriptions = $conn->query($sql_prescriptions);
?>
<link rel="stylesheet"  href="style.css">
<!DOCTYPE html>
<html>
<head>
    <title>Prescriptions Table</title>
    <style>
       
        table {
            border-collapse: collapse;
            width: 100%;
            background-color: yellow;
        }
        th, td {
            border: 1px solid black;
            padding: 8px;
            text-align: left;
        }
    </style>
</head>
<body>
    <h1>Prescriptions Table</h1>

    <?php
    if ($result_prescriptions->num_rows > 0) {
        echo "<table>";
        echo "<tr>";
        echo "<th>Prescription ID</th>";
        echo "<th>Drug Name</th>";
        echo "<th>Dose</th>";
        echo "<th>Frequency</th>";
        echo "<th>Days</th>";
        echo "<th>Quantity</th>";
        echo "<th>Patient ID</th>";
        echo "<th>Patient Name</th>";
        echo "</tr>";
        
        while ($row = $result_prescriptions->fetch_assoc()) {
            echo "<tr>";
            echo "<td>".$row["prescription_id"]."</td>";
            echo "<td>".$row["drug_name"]."</td>";
            echo "<td>".$row["dose"]."</td>";
            echo "<td>".$row["Frequency"]."</td>";
            echo "<td>".$row["Days"]."</td>";
            echo "<td>".$row["quantity"]."</td>";
            echo "<td>".$row["patient_id"]."</td>";
            echo "<td>".$row["patient_name"]."</td>";
            echo "</tr>";
        }

        echo "</table>";
    } else {
        echo "No prescriptions found.";
    }
    ?>
</body>
</html>
