<?php
require_once("config.php");

// Check if the form is submitted for updating drug information
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Retrieve the form data
    $drug_id = $_POST['drug_id'];
    $name = $_POST['name'];
    $dose = $_POST['dose'];
    $expiry_date = $_POST['expiry_date'];
    $pharmaceutical_co = $_POST['pharmaceutical_co'];
    $Price = $_POST['price'];

    // Perform the SQL UPDATE operation using the retrieved data
    $sql = "UPDATE drug SET name='$name', dose='$dose', expiry_date='$expiry_date', 
            pharmaceutical_co='$pharmaceutical_co', Price='$Price' WHERE drug_id='$drug_id'";

    if ($conn->query($sql) === TRUE) {
        echo "Drug information updated successfully.";
    } else {
        echo "Error updating drug information: " . $conn->error;
    }
}

// Check if the drug ID is provided in the URL
if (isset($_GET['id'])) {
    $id = $_GET['id'];
    // Retrieve the drug's information from the database
    $sql = "SELECT * FROM drug WHERE drug_id='$id'";
    $result = $conn->query($sql);
    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();
        $drug_id = $row['drug_id'];
        $name = $row['name'];
        $dose = $row['dose'];
        $expiry_date = $row['expiry_date'];
        $pharmaceutical_co = $row['pharmaceutical_co'];
        $Price = $row['Price'];
    }
}

$conn->close();
?>

<!DOCTYPE html><link rel ="stylesheet"href="style .css"/>
  <html>
  <head>
    <title>Manage Drugs</title>
     <link rel ="stylesheet"href="style .css"/>
    <style>
      body {

        background-color: #f2f2f2;
        font-family: Arial, sans-serif;
      }
      
      h2 {
        text-align: center;
        margin: 20px 0;
      }
      
      form {
        width: 300px;
        margin: 0 auto;
        padding: 20px;
        border: 1px solid #ddd;
        background-color: #fff;
      }
      
      label {
        display: block;
        margin-bottom: 10px;
      }
      
      input[type="text"],
      input[type="date"] {
        width: 100%;
        padding: 8px;
        margin-bottom: 10px;
        border: 1px solid #ddd;
        box-sizing: border-box;
      }
      
      input[type="submit"] {
        background-color: #4CAF50;
        color: white;
        padding: 10px 20px;
        border: none;
        cursor: pointer;
      }
      
      input[type="submit"]:hover {
        background-color: #45a049;
      }
      
      .error-message {
        color: red;
        font-size: 14px;
      }
    </style>
    <link rel ="stylesheet"href="style .css"/>
  </head>
  <body>
    <h1>Edit Drug Details</h1>
    <form method="POST" action="">
        <input type="hidden" name="drug_id" value="<?php echo $drug_id; ?>">
        <label>Name:</label>
        <input type="text" name="name" value="<?php echo $name; ?>"><br>
        <label>Dose:</label>
        <input type="text" name="dose" value="<?php echo $dose; ?>"><br>
        <label>Expiry Date:</label>
        <input type="text" name="expiry_date" value="<?php echo $expiry_date; ?>"><br>
        <label>Pharmaceutical Co:</label>
        <input type="text" name="pharmaceutical_co" value="<?php echo $pharmaceutical_co; ?>"><br>
        <label>Price:</label>
        <input type="text" name="price" value="<?php echo $Price; ?>"><br>
        <input type="submit" value="Update">
    </form>
    <br>
    <a href="manage drugs.php">Back to Drug List</a>
</body>
</html>
