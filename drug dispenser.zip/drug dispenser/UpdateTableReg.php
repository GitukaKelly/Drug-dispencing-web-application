<?php
require_once("Config.php");

// Check if the form is submitted for updating user information
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  // Retrieve the form data
  $id = $_POST['id'];
  $name = $_POST['name'];
  $username = $_POST['username'];
  $email = $_POST['email'];
  $password = $_POST['password'];
  $occupation = $_POST['occupation'];

  // Perform the SQL UPDATE operation using the retrieved data
  $sql = "UPDATE users SET name='$name', username='$username', email='$email', password='$password', Occupation='$occupation' WHERE id='$id'";
  if ($conn->query($sql) === TRUE) {
    echo "User information updated successfully.";
  } else {
    echo "Error updating user information: " . $conn->error;
  }
}

// Check if the user ID is provided in the URL
if (isset($_GET['id'])) {
  $id = $_GET['id'];

  // Retrieve the user's information from the database
  $sql = "SELECT * FROM users WHERE id='$id'";
  $result = $conn->query($sql);

  if ($result->num_rows > 0) {
    $row = $result->fetch_assoc();
    $name = $row['name'];
    $username = $row['username'];
    $email = $row['email'];
    $password = $row['password'];
    $occupation = $row['Occupation'];
  }
}
?>

<!DOCTYPE html>
<html>
<head>
  <title>Edit User</title>
</head>
<body>
  <h1>Edit Details</h1>

  <form method="POST" action="">
    <input type="hidden" name="id" value="<?php echo $id; ?>">
    <label>Name:</label>
    <input type="text" name="name" value="<?php echo $name; ?>">
    <br>
    <label>Username:</label>
    <input type="text" name="username" value="<?php echo $username; ?>">
    <br>
    <label>Email:</label>
    <input type="text" name="email" value="<?php echo $email; ?>">
    <br>
    <label>Password:</label>
    <input type="password" name="password" value="<?php echo $password; ?>">
    <br>
    <label>Occupation:</label>
    <input type="text" name="occupation" value="<?php echo $occupation; ?>">
    <br>
    <input type="submit" value="Update">
    <br>

    <a href="tableReg.php">Back</a>

  </form>
</body>
</html>